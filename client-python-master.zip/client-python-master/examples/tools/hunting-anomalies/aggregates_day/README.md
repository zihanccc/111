Download flat files into here.
