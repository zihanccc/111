Welcome to polygon-api-client's documentation!
==============================================

This documentation is for the Python client only. For details about the responses see `the official docs <https://polygon.io/docs>`_.

.. toctree::
  :maxdepth: 1
  :caption: Contents:

  Getting-Started
  Aggs
  WebSocket
  Snapshot
  Quotes
  Reference
  Trades
  vX
  Models
  Enums
  WebSocket-Enums
  Exceptions
  Contracts

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
