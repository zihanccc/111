.. _exceptions_header:

Exceptions
==============================================================

==============================================================
AuthError
==============================================================
.. autoclass:: polygon.exceptions.AuthError
    :members:
    :undoc-members:  

==============================================================
BadResponse
==============================================================
.. autoclass:: polygon.exceptions.BadResponse
    :members:
    :undoc-members:  

