.. _websocket_enums_header:

WebSocket Enums
==============================

==============================================================
Feed
==============================================================
.. autoclass:: polygon.websocket.models.Feed
    :members:
    :undoc-members:                                  

==============================================================
Market
==============================================================
.. autoclass:: polygon.websocket.models.Market
    :members:
    :undoc-members:         

==============================================================
EventType
==============================================================
.. autoclass:: polygon.websocket.models.EventType
    :members:
    :undoc-members:         