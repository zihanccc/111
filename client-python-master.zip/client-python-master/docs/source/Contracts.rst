.. _contracts_header:

Contracts
=================================

=================================
Get option contract
=================================

- `Options Contract`_

.. automethod:: polygon.RESTClient.get_options_contract

=================================
List Options Contracts
=================================

- `Options Contracts`_

.. automethod:: polygon.RESTClient.list_options_contracts


.. _Options Contract: https://polygon.io/docs/options/get_v3_reference_options_contracts__options_ticker
.. _Options Contracts: https://polygon.io/docs/options/get_v3_reference_options_contracts